<html>
<head>

  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>tcc</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
        
</head>
<html>
<body>
<nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
  <li class="nav-item">
                            <a class="nav-link" href="#Inicio">Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#features">Caracteristicas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#details">Detalhes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#pricing">Preços</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-bs-toggle="dropdown" aria-expanded="false">Drop</a>
                            <ul class="dropdown-menu" aria-labelledby="dropdown01">
                                <li><a class="dropdown-item" href="log-in.html">Entrar</a></li>
                                <li><div class="dropdown-divider"></div></li>
                                <li><a class="dropdown-item" href="sign-up.html">Increva-se</a></li>
                                <li><div class="dropdown-divider"></div></li>
                                <li><a class="dropdown-item" href="article.html">Detalhes do artigo</a></li>
                                <li><div class="dropdown-divider"></div></li>
                                <li><a class="dropdown-item" href="terms.html"> Termos e condiçoes</a></li>
                                <li><div class="dropdown-divider"></div></li>
                                <li><a class="dropdown-item" href="privacy.html">Politica de Privacidade</a></li>
                            </ul>
                        </li>
  </div>
</nav>

    <div class="container">

    <div class="principal">
</body>
</html>